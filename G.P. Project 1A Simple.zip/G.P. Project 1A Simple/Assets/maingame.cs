﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class maingame : MonoBehaviour
{
    Vector2 pos;
    // pos is the x and y positions 
    public Text userFeebackText;
    Vector2 boardSize;
    Vector2 Goal;
    // is the x and y positions for the goal 
    int Flashlight;
    public bool FlashlightOn;
    // if its on 
  
    public AudioSource winner;
    public AudioSource music;
    public AudioSource bang;
    int newFlashlight;
    private float lastDistance;
    // the last distance that the user had
    int numberMoves;
    // the number of moves the person makes 
    // Start is called before the first frame update
    void Start()
    {
        userFeebackText = GameObject.Find("textgame").GetComponent<Text>();
        music = GameObject.Find("ghost01").GetComponent<AudioSource>();
        // main game muisc which is the ghost
        winner = GameObject.Find("cheer").GetComponent<AudioSource>();
        bang = GameObject.Find("HitBoomImpactThud (Movie Trailer Cinematic) - Sound Effect").GetComponent<AudioSource>();
        boardSize.x = 15;
        boardSize.y = 15;
        // end of the board
        Goal.x = Random.value * 15;
        Goal.y = Random.value * 15;
        Debug.Log("Goal is at" + Goal.x + "," + Goal.y);
        Flashlight = 10;
        FlashlightOn = true;

        lastDistance = Vector2.Distance(pos, Goal);

    }

    // Update is called once per frame
    void Update()
    {

    }

    //  move down button
    public void moveDown()
    {
        if (pos.y > 0)
        { pos.y -= 1; }
        else
        {
            bang.Play();

            music.volume = 0; }
        reportUser();


    }

    // move up button
    public void moveForward()
    {

        if (pos.y < boardSize.y)
        { pos.y += 1; }
        else
        {
            bang.Play();

            music.volume = 0; }
        reportUser();
    }

    // move left button 
    public void moveLeft()
    {

        if (pos.x > 0)
        { pos.x -= 1; }
        else
        {
            bang.Play();

            music.volume = 0; }
        reportUser();
    }

    //  move right button 
    public void moveRight()
    {
        if (pos.x < boardSize.x)
        { pos.x += 1; }
        else
        { bang.Play();

            music.volume = 0; }



        reportUser();
    }

    // the toggler button which is my flashlight
    public void headlight(GameObject toggler)
    {

        FlashlightOn = GameObject.Find("headlaptoggle").GetComponent<Toggle>().isOn;

       

    }


    public void reportUser()
    {// the actual distance that the user has
        float actualDistance;

        numberMoves++;
        // counts the number of moves that the person has
        actualDistance = Vector2.Distance(pos, Goal);
        System.String c;
        // if flashlight is on subtract the int number 
        if (FlashlightOn && (Flashlight > 0))
        { Flashlight--;
            // if it equals to zero user can not use any more
            if (Flashlight == 0)
            { FlashlightOn = false;
                GameObject.Find("headlaptoggle").GetComponent<Toggle>().isOn = false;
            }

        }
        // the actual distance equals the goal winning music will play and show the text 
        if (actualDistance < 2)
        {
            //c = "Winner! won in "+ numberMoves +" moves";
            c = "Winner! Number of moves are " + numberMoves + "!";
            music.volume = 0;
            winner.Play();

        }
        else {// if the flashlight is on and it greater than 0 it should print text
            if (FlashlightOn && (Flashlight > 0))
            {
                c = System.String.Format("Position {0},{1} disance is {2}. Flashlight is {3}", pos.x, pos.y, Vector2.Distance(pos, Goal), Flashlight);
                Debug.Log(FlashlightOn ? "Flashlight ON" : "Flashligth OFF");
            }
            else
            {// else it should say this based on if the actual distane is less than the users last distance

                if (actualDistance < lastDistance)
                    c = "your getting warmer";
                else
                    c = "your getting colder"; 

                // plays main music when it gets closer to the goal 
                music.volume = 1 - (Vector2.Distance(pos, Goal) / 5);
            }

        }
        Debug.Log(c);
        userFeebackText.text = c;
        lastDistance = actualDistance;
    }
}